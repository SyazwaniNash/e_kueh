package com.example.e_kueh_a170694.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_kueh_a170694.Dessert;
import com.example.e_kueh_a170694.FoodieDetailActivity;
import com.example.e_kueh_a170694.R;

import java.util.List;

public class DessertRecyclerViewAdapter extends RecyclerView.Adapter<DessertRecyclerViewAdapter.DessertViewHolder> {

    public List<Dessert> dessertList;
    private Context context;
    public DessertRecyclerViewAdapter(Context context,List<Dessert> dessertList) {
        this.context=context;
        this.dessertList = dessertList;
    }

    @NonNull
    @Override
    public DessertViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View dessert_row = LayoutInflater.from(parent.getContext()).inflate(R.layout.dessert_row,null);

        DessertViewHolder dessertVH = new DessertViewHolder(dessert_row);
        return dessertVH;

    }

    @Override
    public void onBindViewHolder(@NonNull DessertViewHolder holder, int position) {
        holder.tvDessertName.setText(dessertList.get(position).getName());
        holder.imageViewDessertImage.setImageResource(dessertList.get(position).getImage());

    }

    @Override
    public int getItemCount() {
        return dessertList.size();
    }

    public class DessertViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public TextView tvDessertName;
        public ImageView imageViewDessertImage;

        public DessertViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDessertName = itemView.findViewById(R.id.tv_dessert_name);
            imageViewDessertImage = itemView.findViewById(R.id.img_dessert);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            Toast.makeText(itemView.getContext(),"Dessert Name:" + dessertList.get(getAdapterPosition()).getName(),Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(v.getContext(), FoodieDetailActivity.class);
            intent.putExtra("Dessert Name",dessertList.get(getAdapterPosition()).getName());
            v.getContext().startActivity(intent);




        }
    }
}
