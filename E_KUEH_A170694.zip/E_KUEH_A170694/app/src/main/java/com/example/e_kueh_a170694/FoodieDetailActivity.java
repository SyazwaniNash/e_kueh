package com.example.e_kueh_a170694;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class FoodieDetailActivity extends AppCompatActivity {
    Button btnAdd, btnMinus, btnCheckOut;
    TextView tvQuantity, tvFoodieNameDetail;
    EditText etName, etAddress;


    int quantity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foodie_detail);

        Intent intent = getIntent();
        TextView tvName = findViewById(R.id.tv_Foodie_Name_Detail);
        tvName.setText(intent.getStringExtra("Dessert Name"));



        btnAdd = findViewById(R.id.btn_add);
        btnMinus = findViewById(R.id.btn_minus);
        btnCheckOut = findViewById(R.id.btn_check_out);
        tvQuantity = findViewById(R.id.tv_quantity);
        etName = findViewById(R.id.et_name);
        etAddress = findViewById(R.id.et_address);
        tvFoodieNameDetail = findViewById(R.id.tv_Foodie_Name_Detail);

        quantity = 1;


        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quantity++;
                tvQuantity.setText(""+ quantity);
            }
        });

        btnMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quantity--;
                tvQuantity.setText(""+quantity);
            }
        });

        btnCheckOut.setOnClickListener(new View.OnClickListener() {
            String name,dessertname;
            String address;

            @Override
            public void onClick(View v) {
                if(editTextIsEmpty())
                    return;

                name = etName.getText().toString();
                dessertname = tvFoodieNameDetail.getText().toString();
                address = etAddress.getText().toString();


                Toast.makeText(FoodieDetailActivity.this," Thank you " + name + " for order: " + quantity + " " + dessertname ,Toast.LENGTH_LONG).show();
                Intent intent = new Intent(FoodieDetailActivity.this,OrderDetailActivity.class);
                intent.putExtra("quantity",quantity);
                intent.putExtra("name",name);
                intent.putExtra("address",address);
                intent.putExtra("dessert name",dessertname);

                startActivity(intent);


            }
        });
    }
    private boolean editTextIsEmpty(){
        if(TextUtils.isEmpty(etName.getText().toString())){
            etName.setError("Cannot be Empty");
        }
        if (TextUtils.isEmpty(etAddress.getText().toString())){
            etAddress.setError("Cannot be Empty");
        }
        if (TextUtils.isEmpty(etName.getText().toString())||TextUtils.isEmpty(etAddress.getText().toString())){
            return true;
        }else
            return false;

    }
}