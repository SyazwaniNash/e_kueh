package com.example.e_kueh_a170694;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Switch;
import android.widget.Toast;

import com.example.e_kueh_a170694.adapter.DessertRecyclerViewAdapter;

import java.util.ArrayList;
import java.util.List;

public class MenuFoodie extends AppCompatActivity {
    LinearLayoutManager linearLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_foodie);

        Toolbar toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);



        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        linearLayoutManager = new LinearLayoutManager(MenuFoodie.this);
        recyclerView.setLayoutManager(linearLayoutManager);

        List<Dessert> allDessertInfor = getAllDessertInfor();
        DessertRecyclerViewAdapter dessertRecyclerViewAdapter = new DessertRecyclerViewAdapter(MenuFoodie.this,allDessertInfor);
        recyclerView.setAdapter(dessertRecyclerViewAdapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.bar_apps,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent intent;
        switch(item.getItemId()){

            case R.id.bar_notification:
                Toast.makeText(MenuFoodie.this,"Notification",Toast.LENGTH_SHORT).show();
                intent = new Intent(MenuFoodie.this,NotificationActivity.class);
                startActivity(intent);
                break;

            case R.id.bar_sync:
                Toast.makeText(MenuFoodie.this,"Sync",Toast.LENGTH_SHORT).show();
                intent = new Intent(MenuFoodie.this,SyncActivity.class);
                startActivity(intent);
                break;

            case R.id.bar_setting:
                Toast.makeText(MenuFoodie.this,"Setting",Toast.LENGTH_SHORT).show();
                intent = new Intent(MenuFoodie.this,SettingActivity.class);
                startActivity(intent);
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private List<Dessert> getAllDessertInfor(){
        List<Dessert> allDessert = new ArrayList<Dessert>();
        allDessert.add(new Dessert("Badak Berendam",R.drawable.badak_berendam));
        allDessert.add(new Dessert("Buah Melaka",R.drawable.buah_melaka));
        allDessert.add(new Dessert("Butir Nangka",R.drawable.butir_nangka));
        allDessert.add(new Dessert("Cara Berlauk",R.drawable.cara_berlauk));
        allDessert.add(new Dessert("Cara Manis",R.drawable.cara_manis));
        allDessert.add(new Dessert("Kuih Kaswi",R.drawable.kiuh_kaswi));
        allDessert.add(new Dessert("Kuih Ketayap",R.drawable.kuih_ketayap));
        allDessert.add(new Dessert("Kuih Lapis",R.drawable.kuih_lapis));
        allDessert.add(new Dessert("Kuih Lompang",R.drawable.kuih_lompang));
        allDessert.add(new Dessert("Lepat Pisang",R.drawable.lepat_pisang));
        allDessert.add(new Dessert("Seri Muka",R.drawable.seri_muka));
        allDessert.add(new Dessert("Tepung Bungkus",R.drawable.tepung_bungkus));
        allDessert.add(new Dessert("Tepung Pelita",R.drawable.tepung_pelita));


        return allDessert;

    }
}