package com.example.e_kueh_a170694;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class NotificationActivity extends AppCompatActivity {

    TextView tvLanguage;
    LinearLayout llSettingNotification, llSettingLanguage;
    Switch switchNotification;

    SharedPreferences sharedPref;
    SharedPreferences.Editor editor;

    String SP_LANGUAGE = "language";
    String SP_NOTIFICATION = "notification";

    String[] values = {"ENGLISH","MELAYU"};
    AlertDialog alertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        tvLanguage = findViewById(R.id.tv_language);
        llSettingNotification = findViewById(R.id.ll_setting_notification);
        llSettingLanguage = findViewById(R.id.ll_setting_language);
        switchNotification = findViewById(R.id.switch_notification);

        sharedPref = getSharedPreferences("app_settings",MODE_PRIVATE);
        editor = sharedPref.edit();

        switchNotification.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean b) {
                editor.putBoolean(SP_NOTIFICATION,b);
                editor.commit();

            }
        });
        switchNotification.setChecked(sharedPref.getBoolean(SP_NOTIFICATION,false));
        tvLanguage.setText(values[sharedPref.getInt(SP_LANGUAGE,0)]);

        llSettingNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean switchState = switchNotification.isChecked();
                switchNotification.setChecked(!switchState);
                editor.putBoolean(SP_NOTIFICATION,!switchState);
                editor.commit();
            }
        });
        llSettingLanguage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowLanguageOption();
            }
        });

    }
    public void ShowLanguageOption(){
        AlertDialog.Builder builder = new AlertDialog.Builder(NotificationActivity.this);
        builder.setTitle("Select your language");
        builder.setSingleChoiceItems(values, sharedPref.getInt(SP_LANGUAGE, 0), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                switch (i){
                    case 0:
                        editor.putInt(SP_LANGUAGE,0);
                        editor.commit();
                        break;

                    case 1:
                        editor.putInt(SP_LANGUAGE,1);
                        editor.commit();
                        break;
                }
                alertDialog.dismiss();
                tvLanguage.setText(values[sharedPref.getInt(SP_LANGUAGE,0)]);

            }
        });
        alertDialog = builder.create();
        alertDialog.show();




    }
}