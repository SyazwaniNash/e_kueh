package com.example.e_kueh_a170694;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;

public class SyncActivity extends AppCompatActivity {
    LinearLayout llSettingSync;
    Switch switchSync;
    SharedPreferences sharedPref;
    SharedPreferences.Editor editor;
    String SP_SYNC = "sync";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sync);

        llSettingSync = findViewById(R.id.ll_setting_sync);
        switchSync = findViewById(R.id.switch_sync);

        sharedPref = getSharedPreferences("app sync",MODE_PRIVATE);
        editor=sharedPref.edit();

        switchSync.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean b) {
                editor.putBoolean(SP_SYNC,b);
                editor.commit();
            }
        });
        switchSync.setChecked(sharedPref.getBoolean(SP_SYNC,false));

        llSettingSync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean switchState = switchSync.isChecked();
                switchSync.setChecked(!switchState);
                editor.putBoolean(SP_SYNC,!switchState);
                editor.commit();

            }
        });




    }
}