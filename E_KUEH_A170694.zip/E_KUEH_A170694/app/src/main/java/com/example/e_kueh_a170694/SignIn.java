package com.example.e_kueh_a170694;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;


public class SignIn extends AppCompatActivity  {

    Button btnlogin;
    EditText etname, etphone, etemail;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);



        btnlogin = findViewById(R.id.btn_login);
        etname = findViewById(R.id.et_name);
        etphone = findViewById(R.id.et_phone);
        etemail = findViewById(R.id.et_email);



        btnlogin.setOnClickListener(new View.OnClickListener() {
            String name,email;
            int phone;

            @Override
            public void onClick(View v) {
                if(editTextIsEmpty())
                    return;
                name = etname.getText().toString();

                Toast.makeText(SignIn.this, " Thank you " + name + " for log in our app. " ,Toast.LENGTH_LONG).show();
                Intent intent = new Intent(SignIn.this,MenuFoodie.class);
                intent.putExtra("name",name);
                intent.putExtra("phone",phone);
                intent.putExtra("email",email);

                startActivity(intent);




            }
        });



    }

    private boolean editTextIsEmpty(){
        if(TextUtils.isEmpty(etname.getText().toString())){
            etname.setError("Cannot be Empty");
        }
        if(TextUtils.isEmpty(etphone.getText().toString())){
            etphone.setError("Cannot be Empty");
        }
        if(TextUtils.isEmpty(etemail.getText().toString())){
            etemail.setError("Cannot be Empty");
        }
        if(TextUtils.isEmpty(etname.getText().toString())||TextUtils.isEmpty(etphone.getText().toString())||TextUtils.isEmpty(etemail.getText().toString())){
            return true;

        }else
            return false;



    }


}