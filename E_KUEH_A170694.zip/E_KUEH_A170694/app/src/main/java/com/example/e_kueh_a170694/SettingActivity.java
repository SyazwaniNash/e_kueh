package com.example.e_kueh_a170694;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

public class SettingActivity extends AppCompatActivity {
    LinearLayout llSettingLogout;
    SharedPreferences sharedPref;
    SharedPreferences.Editor editor;
    AlertDialog alertDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        llSettingLogout = findViewById(R.id.ll_setting_logout);
        sharedPref = getSharedPreferences("Setting",MODE_PRIVATE);
        editor = sharedPref.edit();

        llSettingLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(SettingActivity.this);
                alertDialogBuilder.setTitle("LOG OUT");
                alertDialogBuilder.setMessage("Are you sure you want to logout this app?.");
                alertDialogBuilder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i){
                        Toast.makeText(SettingActivity.this,"Action Cancelled",Toast.LENGTH_SHORT).show();

                    }
                });
                alertDialogBuilder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(SettingActivity.this,"Action Proceed",Toast.LENGTH_SHORT).show();

                    }
                });
                Intent intent = new Intent(SettingActivity.this,LogoutActivity.class);
                startActivity(intent);
                alertDialogBuilder.show();




            }
        });




    }
}