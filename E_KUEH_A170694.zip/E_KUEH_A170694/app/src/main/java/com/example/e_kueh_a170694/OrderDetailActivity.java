package com.example.e_kueh_a170694;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class OrderDetailActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnCancelOrder,btnProceedOrder;
    ImageButton imgButtonCall, imgButtonEmail, imgButtonWeb;
    TextView tvName;
    TextView tvQuantity;
    TextView tvAddress;
    TextView tvFoodieName;
    String name, address, dessertname;
    int quantity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);

        btnProceedOrder = findViewById(R.id.btn_proceed_order);
        btnCancelOrder = findViewById(R.id.btn_cancel_order);

        imgButtonWeb = findViewById(R.id.img_btn_web_order_act);
        imgButtonEmail = findViewById(R.id.img_btn_email_order_act);
        imgButtonCall = findViewById(R.id.img_btn_call_order_act);

        tvAddress = findViewById(R.id.tv_order_address_act);
        tvName = findViewById(R.id.tv_order_name_act);
        tvQuantity = findViewById(R.id.tv_quantity_order_act);
        tvFoodieName = findViewById(R.id.tv_foodie_name_act);


        Intent intent = getIntent();

        name = intent.getStringExtra("name");
        quantity = intent.getIntExtra("quantity",0);
        address = intent.getStringExtra("address");
        //address = tvAddress.getText().toString();
        //dessertname = tvFoodieName.getText().toString();

        //TextView tvFoodieName = findViewById(R.id.tv_foodie_name_act);
        dessertname= intent.getStringExtra("dessert name");


        tvName.setText(name);
        tvQuantity.setText(""+ quantity);
        tvFoodieName.setText(dessertname);
        tvAddress.setText(address);


        imgButtonCall.setOnClickListener(this);
        imgButtonEmail.setOnClickListener(this);
        imgButtonWeb.setOnClickListener(this);

        btnCancelOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(OrderDetailActivity.this,"Your Order has been Cancel.",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(OrderDetailActivity.this,MenuFoodie.class);
                startActivity(intent);

            }
        });
        btnProceedOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(OrderDetailActivity.this,"Your Order has been Proceed,Thank you.",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(OrderDetailActivity.this,MapSearchActivity.class);
                startActivity(intent);

            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.img_btn_call_order_act:
               Intent callIntent = new Intent(Intent.ACTION_DIAL);
               callIntent.setData(Uri.parse("tel: 0187844783 "));
               if(callIntent.resolveActivity(getPackageManager())!=null) {
                   startActivity(callIntent);
               }
               else{
                   Toast.makeText(OrderDetailActivity.this,"sorry, no app can handle this action and data",Toast.LENGTH_SHORT).show();
               }
            break;
            case R.id.img_btn_email_order_act:
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setType("text/plain");
                emailIntent.putExtra(Intent.EXTRA_SUBJECT,"Your Order From MyFoodieApp");
                emailIntent.putExtra(Intent.EXTRA_TEXT,"Email message: Information about order.");
                emailIntent.putExtra(Intent.EXTRA_EMAIL,new String[]{"myfoodieapp@company.com"});
                if(emailIntent.resolveActivity(getPackageManager())!=null) {
                    startActivity(emailIntent);
                }
                else{
                    Toast.makeText(OrderDetailActivity.this,"sorry, no app can handle this action and data",Toast.LENGTH_SHORT).show();
                }

                break;
            case R.id.img_btn_web_order_act:
                Uri webpage = Uri.parse("http://www.google.com");
                Intent webIntent = new Intent(Intent.ACTION_VIEW,webpage);

                if(webIntent.resolveActivity(getPackageManager())!=null) {
                    startActivity(webIntent);
                }
                else{
                    Toast.makeText(OrderDetailActivity.this,"sorry, no app can handle this action and data",Toast.LENGTH_SHORT).show();
                }


                break;


        }


    }
}